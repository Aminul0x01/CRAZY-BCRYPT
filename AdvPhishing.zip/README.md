<p align="right">
  <a><img title="Built With Love" src="https://forthebadge.com/images/badges/uses-html.svg" ></a>
 </p>
<p align="center">
<a href="https://github.com/Ignitetch/AdvPhishing/releases"><img title="GitHub version" src="https://img.shields.io/badge/version-2.2-blue" ></a>  
</p>
<img src="https://user-images.githubusercontent.com/55870659/92557010-185f5e80-f220-11ea-8d70-6a5208433ea6.png">
<p align="center">
  <b> Follow on Social Media Platforms </b>
</p>
<p align="center">
<a href="https://www.facebook.com/secnhack"><img title="GitHub version" src="https://img.shields.io/badge/-Facebook-blue" ></a><a href="https://www.youtube.com/channel/UCfBDWui9dSRbCmT32jf848Q"><img title="GitHub version" src="https://img.shields.io/badge/-youtube-red" ></a><a href="https://twitter.com/secnhack?lang=en"><img title="GitHub version" src="https://img.shields.io/badge/-Twitter-blue" ></a>
</p>
<p align="center">
  <b> Contribute us</b>
</p>
<p align="center">
<a href="https://www.paypal.com/paypalme2/Goyal827"><img title="GitHub version" src="https://camo.githubusercontent.com/ae8af018f80649f3d379eb23dbf59acceaffa24e/68747470733a2f2f6c69626572617061792e636f6d2f6173736574732f776964676574732f646f6e6174652e737667"></a>
</p>
<p align="center">
  <b> Want to Learn to Create Professional Phishing Page, Ethical Hacking, Bug Bounty visit - https://basichacker.in  </b>
</p>

<br>
<br>
<br>
<br>

### Join Our Whastapp Group For Any Queries and Learn Hacking 
* https://chat.whatsapp.com/J6FCipjBwg76UGI7Px2oae  -- If its Full
* https://chat.whatsapp.com/LFDAwmHkYDe1XI18AiKbLS  -- If its Full
* https://chat.whatsapp.com/IPc4q8uifaQDoqSxJrguW1  -- If its Full
* https://chat.whatsapp.com/HbPQoqTRLyV15GdBF4B5iw  -- If its Full
* https://chat.whatsapp.com/KoZJRTzSVmY7IwpmsLxDTm --  If its Full
* https://chat.whatsapp.com/FVI56kzsnkI7RaAOIH2E1S --  If its Full
* https://chat.whatsapp.com/Ge1rgCfkmR91cYuNkfmEdm --  If its Full
* https://chat.whatsapp.com/HzbioqQ5XXH10YoJkYwl6V -- If its Full
* https://chat.whatsapp.com/HSRHmvNLwNd5wtz12jw4Gl -- If its Full

Telegrams 
* https://t.me/Secnhacks 

Signal Group
* https://signal.group/#CjQKIJo2kROhQqGixd42Rhrn5xvxnjeuOZTiSzuyTwXnIaYSEhB7VUxzQ26H3q5MU9nQv1_5




### TECHNIQUE
When victim enter his credentials, you need to go to original website and use those credentials to send real OTP to victim. Once he enter that OTP such OTP will also be there with you and you will be allowed to login the account before him.

### TUTORIAL [ KALI ]
[(![des](https://user-images.githubusercontent.com/55870659/77065337-7b7de000-69b7-11ea-915d-4dad81d2e892.png)](https://www.youtube.com/watch?v=U1nYsNLlFsw)

### SCREENSHOT ( KALI )
![1](https://user-images.githubusercontent.com/55870659/92330976-02e00e00-f041-11ea-9c32-bc33d2971b06.png)
![2](https://user-images.githubusercontent.com/55870659/92331173-a8e04800-f042-11ea-8fd9-5aee83441280.png)

<br>
<br>

-----------------------------------------------------------------------------------------------------
### WHAT's New In AdvPhishing 2.2 Release 
Through This Features You can Obtains the Credentails on Your Gmail Account or Send to Someone Else.
<br>
### Process
* Sender : Open config.php File Through nano or your favorite tool and enter name, your email id, your password.
* Receiver : Which you want to send the Credentials.

![3](https://user-images.githubusercontent.com/55870659/95553917-54cbd900-09dd-11eb-97f3-d50ca49fb3d3.png)
![4](https://user-images.githubusercontent.com/55870659/95553966-690fd600-09dd-11eb-94c1-95ddc60aa687.png)

* Open your emial ID that you mentioned in sende, go security options, scroll down and trun on less secure setting. That's IT :) !!
![5](https://user-images.githubusercontent.com/55870659/95554016-77f68880-09dd-11eb-8530-fbe7a6f649e1.png)

### Results You Can See Here :) !!

![1](https://user-images.githubusercontent.com/55870659/95554077-93619380-09dd-11eb-861c-084e5b123c79.png)
![2](https://user-images.githubusercontent.com/55870659/95554085-9492c080-09dd-11eb-95c6-cfe86214b451.png)
--------------------------------------------------------------------------------------------------------------
<br>



### INSTALLATION [ TERMUX APP --ANDROID ]
* git clone https://github.com/Ignitetch/AdvPhishing.git
* cd AdvPhishing/
* chmod 777 *
* ./Android-Setup.sh
* ./AdvPhishing.sh

### INSTALLATION [ KALI ]
* git clone https://github.com/Ignitetch/AdvPhishing.git
* cd AdvPhishing/
* chmod 777 *
* ./Linux-Setup.sh
* ./AdvPhishing.sh

### AVAILABLE TUNNELLING OPTIONS
1. LOCALHOST
2. NGROK (https://ngrok.com/)
### TESTED ON FOLLOWING:-
* Kali Linux - 2020.1a (version)
* Parrot OS - Rolling Edition (version)
* Ubuntu - 18.04 (version)
* Arch Linux
* Termux App
### PREREQUISITES
* sudo - [ MUST ]
* php
* apache2
* ngrok Token
### LANGUAGE 
* Bash Script


### Contact For Contribute & Issues 

                                      EMAIL FOR ISSUES AND CONTRIBUTE : sg5479845@gmail.com

### DISCLAIMER
                                       TO BE USED FOR EDUCATIONAL PURPOSES ONLY

The use of the Adv-Phishing is COMPLETE RESPONSIBILITY of the END-USER. Developers assume NO liability and are NOT responsible for any misuse or damage caused by this program. 
